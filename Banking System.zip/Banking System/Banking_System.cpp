/// Project Name- "Banking System"
/// Submitted By- "Shah Jafor Sadeek Quaderi >>> CSE-107 >>> Section - 5"
/// ID-"2014-2-60-075"
/// Reference- This Project Successfully Compiled On Jafor's PC & Fahim PC in Visual Stdio 2013
/// You May Change Branch & AccountNumber

#include<iostream>
#include<istream>
#include<cstdio>
#include<string>

#define Branch 2
#define AccountNumber 3
#define Manager 2
#define Accountant 2
#define AccountHolderBonusPercentage 2
#define NameLength 50

using namespace std;

class Bank_Info
{
public:
    friend ostream& operator << (ostream& output, const Bank_Info &BNK)     // Operator Overloading
    {
        output << "Bank Name:- Platinum-Ion" << endl;
        output << "It's the branch of Platinum-Ion Internation Bank, Spain" << endl;
        output << "Our Facilities & Services-\n" << endl;
        output << "* International banking system." << endl;
        output << "* Interest for Account Holders" << endl;
        output << "* Loan for Account older" << endl;
        output << "* ATM Facility." << endl;
        output << "* Money Transfer." << endl;
        output << "# Additinal Information:-" << endl;
        output << "\t\tTotal Branch                  :- " << Branch << endl;
        output << "\t\tAccount Holder On Each Branch :- " << AccountNumber << "\n" << endl;
        output << "***********************************************************" << endl;
        return output;
    }
};

class AC_Holder_Info
{
private:
	int accountNumber;
	char Name[NameLength];
	float Balance;
	float Withdraw, Deposit;
public:
	AC_Holder_Info()						// Constructor of AC_Bank_Info Class
	{
		static int temp1;
		static int temp2;
		accountNumber = 110000 + ((temp2 + 1) * 100) + (temp1 + 1);     // Couting Branch & Accountant
		temp1++;
		if (temp1 == AccountNumber)
		{
			temp1 = 0;
			temp2++;
		}
	}
	int getAccountNumberCounter()const
	{
		return accountNumber;
	}
	void inputName()
	{
	    cin.get(Name, NameLength);
		fflush(stdin);
	}
	void setName(char name[NameLength])
	{
	    Name[NameLength] = name[NameLength];
	}
	char* getName()
	{
	    return Name;
	}
	void inputAccountHolderBalanceInformation(int i, int j)     // Taking Accountant Information
	{
		cout << "Branch- " << i + 1 << ", Account Number: " << getAccountNumberCounter() << ", Name- " ;
		inputName();
        cout << "Your Balance of amount is: ";
		cin >> Balance;
		fflush(stdin);
	}
	void showAccountHolderBalanceInformation(int i, int j)      // Showing Accountant Information
	{
		cout << "Branch- " << i + 1 << ", Account Number: " << getAccountNumberCounter() << ", Name- " << getName() << endl;
		cout << "Your current Balance is: " << Balance << endl;
		fflush(stdin);
	}
	AC_Holder_Info(float balance)
	{
		Balance = balance;
	}
	float getAccountHolderBalanceInformation()
	{
		return Balance;
	}
	void inputAccountHolderWithdrawAmount(int i, int j)     // Taking Withdraw Amount
	{
	    cout << "\n" << endl;
		cout << "Branch- " << i + 1 << ", Account Number: " << getAccountNumberCounter() << ", Name- " << getName() << endl;
		cout << "How much amount you want to Withdraw ?" << endl;
		cout << "Your Withdrawing amount is: ";
		cin >> Withdraw;
		fflush(stdin);
		if (Balance >= Withdraw)
		{
			cout << "You can Withdraw your money " << endl;
			Balance = Balance - Withdraw;
		}
		else
		{
			cout << "You can not Withdraw your money " << endl;
		}
		cout << "/n" << endl;
		fflush(stdin);
	}
	void inputAccountHolderDepositAmount(int i, int j)      // Taking Deposit Amount
	{
		cout << "Branch- " << i + 1 << ", Account Number: " << getAccountNumberCounter() << ", Name- " << getName() << endl;
		cout << "How much amount you want to Deposit ?" << endl;
		cout << "Your Depositing amount is: ";
		cin >> Deposit;
		fflush(stdin);
		Balance = Deposit + Balance;
	}
	void showAccountHolderInterestAmount(int i, int j)      // Accountant Holder Interest Amount
	{
		Balance = Balance + Balance * (AccountHolderBonusPercentage / 100);
		cout << "Branch- " << i + 1 << ", Account Number: " << getAccountNumberCounter() << ", Name- " << getName() << endl;
		cout << "After getting 2% interest your current Balance is: " << Balance << endl;
		fflush(stdin);
	}
	~AC_Holder_Info()						// Distructor of AC_Bank_Info Class
	{
		cout << "AC_Holder_Info Constructor Has Distructred" << endl;
	}
};

class Loan  // Abstract Base Class
{
private:
    float loanAmount;
public:
    Loan()                      // Constructor of Loan Class (No Argument)
    {
        loanAmount = 0;
    }
    void showLoanAmount(int i, int j, AC_Holder_Info ACH[][AccountNumber])
    {
        cout << "Branch- " << i + 1 << ", Account Number: " << ACH[i][j].getAccountNumberCounter() << ", Name- " << ACH[i][j].getName() << endl;
		cout << "Are  you want to take Loan ?" << endl;
    LOAN:
		cout << "Press 'Y'/'y' for 'Yes' or 'N'/'n' for 'No'." << endl;
		char Selection;
		cin >> Selection;
		fflush(stdin);
		if(Selection != 'Y' && Selection != 'y' && Selection != 'N' && Selection != 'n')
        {
            cout << "Wront Input \n"  << endl;
            goto LOAN;
        }
		else if(Selection == 'Y' || Selection == 'y')
        {
            cout << "\n\nInput your loan- ";
            cin >> loanAmount;
            if (loanAmount > ACH[i][j].getAccountHolderBalanceInformation() * .15 )
            {
                cout << "You can't take this amount of loan " << endl;
                ACH[i][j].showAccountHolderBalanceInformation(i,j);
                cout << "\n" << endl;
                cout <<"So please confirm again your decision." << endl;
                goto LOAN;
            }
            else
            {
                cout << "You can take " << getLoan() << " tk from of loan" << endl;
                loanAmount = ACH[i][j].getAccountHolderBalanceInformation() + loanAmount;
                cout << "After getting loan your current amount- "<< loanAmount << " tk\n" << endl;
            }
        }
        else if(Selection == 'N' || Selection == 'n')
		{
			ACH[i][j].showAccountHolderBalanceInformation(i,j);
		}
		cout << "\n";
		fflush(stdin);
    }
    void calculateLoan(int i, int j, AC_Holder_Info ACH[][AccountNumber])
    {
        loanAmount = (ACH[i][j].getAccountHolderBalanceInformation() * .15 );
    }
    void setLoan(float loanamount)
    {
        loanAmount = loanamount;
    }
    float getLoan()
    {
        return loanAmount;
    }
    ~Loan()						// Distructor of Loan Class
	{
		cout << "Loan Constructor Has Distructred" << endl;
	}

};

class AccountHolderWithLoan : public AC_Holder_Info, public Loan
{
private:
    float accountHolderLoan;
public:
    AccountHolderWithLoan()         // Constructor of AccountHolderWithLoan Class (No Argument)
    {
        accountHolderLoan = 0;
    }
    void calculateAccountHolderLoan()
    {
        accountHolderLoan = getLoan();
    }
    void setAccountHolderLoan(float accountholderloan)
    {
        accountHolderLoan = accountholderloan;
    }
    float getAccountHolderLoan()
    {
       return accountHolderLoan;
    }
    ~AccountHolderWithLoan()		// Distructor of AccountHolderWithLoan Class
	{
		cout << "AccountHolderWithLoan Constructor Has Distructred" << endl;
	}
};


class Branch_Info
{
private:
	float branchTotal;
public:
	Branch_Info()                       // Constructor of Branch_Info Class (No Argument)
	{
	    branchTotal = 0;
	}
	void calculateBranchTotalTransaction(int i, AC_Holder_Info ACH[][AccountNumber])
	{
		int j;
		float Sum = 0;
		for (j = 0; j < AccountNumber; j++)
		{
			Sum = Sum + ACH[i][j].getAccountHolderBalanceInformation();     // Calculating Branch Total
		}
		branchTotal = Sum;
		fflush(stdin);
	}
	Branch_Info(float branchtotal)
	{
		branchTotal = branchtotal;
	}
    friend ostream& operator << (ostream& output, Branch_Info &BRNCH)
	{
	    int i;
	    output << "Branch- " << i + 1 << " total Transaction is: " << BRNCH.getBranchTotalTransaction() << endl;
        output << "\n";
        return output;
	}
	float getBranchTotalTransaction()const
	{
		return branchTotal;
	}
	~Branch_Info()						// Distructor of Branch_Info Class
	{
		cout << "Branch_Info Constructor Has Distructred" << endl;
	}
};

class Employee_Info  // Abstract Base Class
{
protected:
	float bonusAmount;
	float sum;
	float bonusPercentage;
public:
	Employee_Info()                       // Constructor of Employee_Info Class (No Argument)
	{
		bonusAmount = 0;
	}
	Employee_Info(float bonusamount)
	{
		bonusAmount = bonusamount;
	}
	void showBonusAmount(int i, float Percentage, int Start, int End, AC_Holder_Info ACH[][AccountNumber])
	{
		int j;
		float Sum = 0;
		for (j = Start - 1; j < End; j++)       // Calculating Employee Bonus Amount
		{
			Sum = Sum + (ACH[i][j].getAccountHolderBalanceInformation() * (Percentage / 100));
		}
		bonusAmount = Sum;
		fflush(stdin);
	}
	float getEmployeeBonus()
	{
		return bonusAmount;
	}
};

class Accountant_Info : public Employee_Info
{
    private:
        int accountantBonusPercentage;
	public:
		Accountant_Info()                       // Constructor of Accountant_Info Class (No Argument)
		{
            accountantBonusPercentage = 3;
		}
		int getAccountantBonusPercentage()
		{
		    return accountantBonusPercentage;
		}
		float getAccountantBonusAmount()
		{
			return bonusAmount;
		}

};

class Manager_Info : public Employee_Info
{
    private:
        int managerBonusPercentage;
	public:
		Manager_Info()                       // Constructor of Manager_Info Class (No Argument)
		{
           managerBonusPercentage = 5;
		}
		int getManagerBonusPercentage()
		{
		    return managerBonusPercentage;
		}
		float getManagerBonusAmount()
		{
			return bonusAmount;
		}
};

int main()
{
Bank_Info                 BNK_Info;                            // Object of Bank_Info
Branch_Info               BR_Info[Branch];                     // Object of Branch_Info
AC_Holder_Info            ACh_Info[Branch][AccountNumber];     // Object of AC_Holder_Info
AccountHolderWithLoan     Ach_Loan_Info[Branch][AccountNumber];// Object of AccountHolderWithLoan
Accountant_Info           ACNTNT_Info[Accountant];             // Object of Accountant_Info
Manager_Info              MNG_Info[Manager];                   // Object of Manager_Info

cout << "       **** *      *  ***** *** *   * *   * *    *     *** ***** **  * " << endl;
cout << "       *  * *     * *   *    *  **  * *   * **  **      *  *   * **  * " << endl;
cout << "       **** *    *****  *    *  * * * *   * * ** * ***  *  *   * * * * " << endl;
cout << "       *    *    *   *  *    *  * * * *   * *    *      *  *   * * * * " << endl;
cout << "       *    *    *   *  *    *  *  ** *   * *    *      *  *   * *  ** " << endl;
cout << "       *    **** *   *  *   *** *   * ***** *    *     *** ***** *   * " << endl;
cout << "!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!" << endl;

cout << "WELCOME TO ***PLATINUM-ION BANK***" << endl;

for(int i =0 ; ; i++)
{

MENU:
cout << "\n\n\n" << endl;
cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
cout << "Choose Option From The List: " << endl;
cout << "(Press 0,1,2,3,4,5,6,7,8,9 Enter for selection)\n\n" << endl;

cout << "1. About Platinum-Ion Bank." << endl;
cout << "2. Set Balance." << endl;
cout << "3. Balance Information." << endl;
cout << "4. Withdraw Amount." << endl;
cout << "5. Deposit Amount." << endl;
cout << "6. Interest Amount." << endl;
cout << "7. Loan." << endl;
cout << "8. Branch Total." << endl;
cout << "9. Employee Bonus." << endl;
cout << "0. Exit." << endl;


cout << "\nEnter your option fromt the menu>>> ";
int Option_Choose;
cin >> Option_Choose;
cout << "\n" << endl;

if(Option_Choose == 0)
{
    cout << "!!!Thankx a lot to visit our Bank!!!\n\n\n\n" << endl;
    return 0;
}

if(Option_Choose > 9)
{
    cout <<"You have choosen wrong information, please select correct option.\n" << endl;
    goto MENU;
}


switch(Option_Choose)
{
case 1:
    {
    cout << BNK_Info;   // Showing Bank Information
    cout << "\n\n";
    break;
    }
case 2:
    {
    for (int i = 0; i < Branch; i++)
		{
			for (int j = 0; j < AccountNumber; j++)
			{
			    fflush(stdin);
                ACh_Info[i][j].inputAccountHolderBalanceInformation(i, j);  // Taking Accountant Balance Holder Information
                cout << "\n";
			}
			cout << "\n";
		}
    }
    break;
case 3:
    {
    for (int i = 0; i < Branch; i++)
		{
			for (int j = 0; j < AccountNumber; j++)
			{
			    fflush(stdin);
				ACh_Info[i][j].showAccountHolderBalanceInformation(i, j);   // Showing Accountant Balance Holder Information
				cout << "\n";
			}
			cout << "\n";
			fflush(stdin);
		}
    }
    break;
case 4:
    {
    for (int i = 0; i < Branch; i++)
		{
			for (int j = 0; j < AccountNumber; j++)
			{
			    fflush(stdin);
				ACh_Info[i][j].inputAccountHolderWithdrawAmount(i, j);          // Taking Withdraw Amount
				cout << "\n" << endl;
				ACh_Info[i][j].showAccountHolderBalanceInformation(i, j);       // Showing Accountant Holder Balance Information
			}
			cout << "\n";
			fflush(stdin);
		}
    }
    break;
case 5:
    {
    for (int i = 0; i < Branch; i++)
		{
			for (int j = 0; j < AccountNumber; j++)
			{
			    fflush(stdin);
				ACh_Info[i][j].inputAccountHolderDepositAmount(i, j);       // Taking Deposit Amount
				cout << "\n" << endl;
				ACh_Info[i][j].showAccountHolderBalanceInformation(i, j);   // Showing Accountant Holder Balance Information
				cout << "\n";
			}
			cout << "\n";
			fflush(stdin);
		}
    }
    break;
case 6:
    {
     for (int i = 0; i < Branch; i++)
		{
			for (int j = 0; j < AccountNumber; j++)
			{
			    fflush(stdin);
				ACh_Info[i][j].showAccountHolderInterestAmount(i, j);       // Accountant Holder Interest Amount Onformation
			}
			cout << "\n";
		}
    }
    break;
case 7:
    {
    for (int i = 0; i < Branch; i++)
		{
			for (int j = 0; j < AccountNumber; j++)
			{
			    fflush(stdin);
                Ach_Loan_Info[i][j].showLoanAmount(i, j, ACh_Info);     // Showing Accountant Holder Loan Information
				cout << "\n";
			}
			cout << "\n";
			fflush(stdin);
		}
    }
    break;
case 8:
    {
    for (int i = 0; i < Branch; i++)
		{
		    fflush(stdin);
		    BR_Info[i].calculateBranchTotalTransaction(i, ACh_Info);        // Showing Branch Total Information
            cout << BR_Info[i];
		}
    }
    break;
case 9:
    {
    for (int i = 0; i < Branch; i++)        // Calculating Accountant Bonus Amount
		{
        fflush(stdin);
		ACNTNT_Info[i].showBonusAmount(i, ACNTNT_Info[i].getAccountantBonusPercentage(), (AccountNumber/AccountNumber), (AccountNumber/2), ACh_Info);
		cout << "Branch- " << i + 1 << " Accounatant- 1 You have got bonus Amount is: " << ACNTNT_Info[i].getAccountantBonusAmount() << endl;
		cout << "\n";
		fflush(stdin);
		ACNTNT_Info[i].showBonusAmount(i, ACNTNT_Info[i].getAccountantBonusPercentage(), (AccountNumber / 2) + 1, AccountNumber, ACh_Info);
		cout << "Branch- " << i + 1 << " Accounatant- 2 You have got bonus Amount is: " << ACNTNT_Info[i].getAccountantBonusAmount() << endl;
		cout << "\n";
		}
		cout << "\n\n";
		for (int i = 0; i < Branch; i++)        // Calculating Manager Bonus Amount
		{
        fflush(stdin);
		MNG_Info[i].showBonusAmount(i, MNG_Info[i].getManagerBonusPercentage(), (AccountNumber/AccountNumber), (AccountNumber), ACh_Info);
		cout << "Branch- " << i + 1 << " Manager You have got bonus Amount is: " << MNG_Info[i].getManagerBonusAmount()<< endl;
		cout << "\n";
		}
    }
    break;
default:
    cout << "You have pressed wrong input... Please Choose Right Option\n\n" << endl;
    goto MENU;

}
}
		cout << "\n\n" << endl;
		fflush(stdin);
		getchar();
		return 0;
}

